package com.yelpTest;

import java.io.IOException;
import com.google.gson.*;

public class Main {

    public static void main(String[] args) throws IOException {
        SearchRequest req = new SearchRequest("spa","Vancouver");
        Gson gson =new Gson();


        String response = req.SendRequest();
        Businesses test = gson.fromJson(response,Businesses.class);

    }
}
