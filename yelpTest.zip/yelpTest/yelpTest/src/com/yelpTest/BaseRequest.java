package com.yelpTest;

public abstract class BaseRequest {

    //PUT API KEY IN HERE

    public String API_KEY = "Dok0Qe_yfviIv19PZj2055QqqN8X1WJPmRP0_p5fRD-wZqqP6ZcNa8JFRW7wn_xPMCTN_7zm70mQEjhj0-840m5ObhocBonNEynojaCYt2eHD7LJdHbDjniNu0frW3Yx";
}
