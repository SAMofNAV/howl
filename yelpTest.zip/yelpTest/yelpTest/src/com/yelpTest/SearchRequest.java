package com.yelpTest;

import javax.net.ssl.HttpsURLConnection;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.*;
import java.util.*;
import java.io.*;

public class SearchRequest extends BaseRequest {

    private String keyword;
    private String location;

    public SearchRequest(String keyword, String location)
    {
        this.keyword = keyword;
        this.location = location;
    }

    public String SendRequest() throws IOException {
        String urlString = String.format("https://api.yelp.com/v3/businesses/search?term=%s&location=%s",keyword,location);
        URL url = new URL(urlString);

        HttpsURLConnection con  = (HttpsURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Authorization","Bearer "+API_KEY);

    /*
        Map<String,String>parameters = new HashMap<>();
        parameters.put("location",this.location);
        parameters.put("term",this.keyword);

        con.setDoOutput(true);
        DataOutputStream out = new DataOutputStream(con.getOutputStream());
        out.writeBytes(getParamsString(parameters));
        out.flush();
        out.close();*/
        int blah = con.getResponseCode();

        String test = con.toString();

        BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        in.close();

        con.disconnect();

        return content.toString();

    }

    public void SetParams(String keyword, String location)
    {
        this.keyword = keyword;
        this.location = location;
    }

    private  static String getParamsString(Map<String, String> params)
            throws UnsupportedEncodingException{
        StringBuilder result = new StringBuilder();

        for (Map.Entry<String, String> entry : params.entrySet()) {
            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            result.append("&");
        }

        String resultString = result.toString();
        return resultString.length() > 0
                ? resultString.substring(0, resultString.length() - 1)
                : resultString;
    }
}
