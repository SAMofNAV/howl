package csis2300.howl;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String BASE_URL = "https://api.foursquare.com/v2/venues/";
    public static final String API_VERSION = "&v=20181115";
    public static String clientID;
    public static String apiKey;
    public ListView lstResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clientID = getString(R.string.clientID);
        apiKey = getString(R.string.apiKey);
        lstResults = findViewById(R.id.lstResults);

        //There are more steps to getting the devices location. will hard code for now.
        //Can find how to get device location at https://stackoverflow.com/questions/2227292/how-to-get-latitude-and-longitude-of-the-mobile-device-in-android
        //TODO: Get lat and long from device. Make helper method for this
        double latitude =  49.282156;
        double longitude = -123.135317;

        recomRestaurants(latitude, longitude);
    }

    //Populates a list of recommended restaurants given the devices latitude and
    //longitude. Max of 5 restaurants in recommendation list.
    public void recomRestaurants(double latitude, double longitude){
        String url = BASE_URL +
                "explore?section=food&limit=5&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        JsonObjectRequest restaurantsObject = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            String name;
            Double lat, lng;
            List<Restaurant> result = new ArrayList<>(); //The resulting list of restaurants.

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    //Parse the JSON response up to the array of restaurant info.
                    JSONObject response_object = response.getJSONObject("response");
                    JSONArray groups_array = response_object.getJSONArray("groups");
                    JSONObject places = groups_array.getJSONObject(0);
                    JSONArray restaurants = places.getJSONArray("items");

                    for(int i = 0; i < restaurants.length(); i++){
                        JSONObject restaurant = restaurants.getJSONObject(i).getJSONObject("venue");
                        JSONObject location = restaurant.getJSONObject("location");

                        name = restaurant.getString("name");
                        lat = location.getDouble("lat");
                        lng = location.getDouble("lng");
                        result.add(new Restaurant(name, lat, lng));
                    }
                    updateListView(result);

                }catch(JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(restaurantsObject);
    }

    //takes a list of restaurants and puts there names in our list view.
    private void updateListView(List<Restaurant> restaurants) {
        List<String> itemsList = new ArrayList<>();

        //fetch the names of the restaurants and puts them in our items list.
        for (Restaurant restaurant:
             restaurants) {
            itemsList.add(restaurant.get_name());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, itemsList);
        lstResults.setAdapter(adapter);

        adapter.notifyDataSetChanged();
    }
}

//How to add items to a ListView:
//
//        final ListView lstResults = findViewById(R.id.lstResults);
//        final Button btnMap = findViewById(R.id.btnMap); //I needed any button
//
//        String[] items = {"a", "b", "c"};
//        final List<String> itemsList = new ArrayList<>(Arrays.asList(items));
//
//        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_list_item_1, itemsList);
//        lstResults.setAdapter(adapter);
//
//        btnMap.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                itemsList.add("Blaaah");
//                adapter.notifyDataSetChanged();
//            }
//        });