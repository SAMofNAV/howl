package csis2300.howl;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String BASE_URL = "https://api.foursquare.com/v2/venues/";
    public static final String API_VERSION = "&v=20181115";
    public static String clientID;
    public static String apiKey;
    public ListView lstResults;
    LocationManager locationManager;
    Location lastKnownLocation;


    double latitude =  49.282156;
    double longitude = -123.135317;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
//        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
//                PackageManager.PERMISSION_GRANTED) {
//
//            lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//
//        } else {
//
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
//        }
        clientID = getString(R.string.clientID);
        apiKey = getString(R.string.apiKey);
        lstResults = findViewById(R.id.lstResults);

//        latitude = lastKnownLocation.getLatitude();
//        longitude = lastKnownLocation.getLongitude();

        //There are more steps to getting the devices location. will hard code for now.
        //Can find how to get device location at https://stackoverflow.com/questions/2227292/how-to-get-latitude-and-longitude-of-the-mobile-device-in-android
        //TODO: Get lat and long from device. Make helper method for this

        recomRestaurants(latitude, longitude, "explore?section=food&limit=5");

        //Search button
        Button btnSearch = findViewById(R.id.btnSearch);
        final EditText txtSearch = findViewById(R.id.txtSearch);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = "search?query=" + txtSearch.getText().toString();
                searchRestaurants(latitude, longitude, url);

            }
        });

        // Map Button
        // i cannot start the Map activity
        Button btnMap = findViewById(R.id.btnMap);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);

            }
        });

    }

    //Populates a list of recommended restaurants given the devices latitude and
    //longitude. Max of 5 restaurants in recommendation list.
    public void recomRestaurants(double latitude, double longitude, String inputUrl){
        String url = BASE_URL +
                inputUrl + "&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        JsonObjectRequest restaurantsObject = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            String name;
            Double lat, lng;
            List<Restaurant> result = new ArrayList<>(); //The resulting list of restaurants.

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    //Parse the JSON response up to the array of restaurant info.
                    JSONObject response_object = response.getJSONObject("response");
                    JSONArray groups_array = response_object.getJSONArray("groups");
                    JSONObject places = groups_array.getJSONObject(0);
                    JSONArray restaurants = places.getJSONArray("items");

                    for(int i = 0; i < restaurants.length(); i++){
                        JSONObject restaurant = restaurants.getJSONObject(i).getJSONObject("venue");
                        JSONObject location = restaurant.getJSONObject("location");

                        name = restaurant.getString("name");
                        lat = location.getDouble("lat");
                        lng = location.getDouble("lng");
                        result.add(new Restaurant(name, lat, lng));
                    }
                    updateListView(result);

                }catch(JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(restaurantsObject);
    }
    public void searchRestaurants(double latitude, double longitude, String inputUrl){
        String url = BASE_URL +
                inputUrl + "&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        JsonObjectRequest restaurantsObject = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            String name;
            Double lat, lng;
            List<Restaurant> result = new ArrayList<>(); //The resulting list of restaurants.

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    //Parse the JSON response up to the array of restaurant info.
                    JSONObject response_object = response.getJSONObject("response");
                    JSONArray venues_array = response_object.getJSONArray("venues");


                    for(int i = 0; i < venues_array.length(); i++){
                        JSONObject restaurant = venues_array.getJSONObject(i);
                        JSONObject location = restaurant.getJSONObject("location");

                        name = restaurant.getString("name");
                        lat = location.getDouble("lat");
                        lng = location.getDouble("lng");
                        result.add(new Restaurant(name, lat, lng));
                    }
                    updateListView(result);

                }catch(JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(restaurantsObject);
    }

    //takes a list of restaurants and puts there names in our list view.
    private void updateListView(List<Restaurant> restaurants) {
        List<String> itemsList = new ArrayList<>();

        //fetch the names of the restaurants and puts them in our items list.
        for (Restaurant restaurant:
             restaurants) {
            itemsList.add(restaurant.get_name());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, itemsList);
        lstResults.setAdapter(adapter);

        lstResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        adapter.notifyDataSetChanged();
    }
}

//How to add items to a ListView:
//
//        final ListView lstResults = findViewById(R.id.lstResults);
//        final Button btnMap = findViewById(R.id.btnMap); //I needed any button
//
//        String[] items = {"a", "b", "c"};
//        final List<String> itemsList = new ArrayList<>(Arrays.asList(items));
//
//        final ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
//                android.R.layout.simple_list_item_1, itemsList);
//        lstResults.setAdapter(adapter);
//
//        btnMap.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                itemsList.add("Blaaah");
//                adapter.notifyDataSetChanged();
//            }
//        });