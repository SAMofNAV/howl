package csis2300.howl;

import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.model.LatLng;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public static final String BASE_URL = "https://api.foursquare.com/v2/venues/";
    public static final String API_VERSION = "&v=20181115";
    public static String clientID;
    public static String apiKey;
    public ListView lstResults;
    public Spinner spinFilter;
    public Button btnSearch;
    public EditText txtSearch;
    public Button btnMap;

    LocationManager locationManager;
    Location lastKnownLocation;

    static List<String> itemsList = new ArrayList<>();
    static  ArrayList<LatLng> locations = new ArrayList<>();
    double latitude =  49.2036;
    double longitude = -122.9127;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
//        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
//                PackageManager.PERMISSION_GRANTED) {
//
//            lastKnownLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//
//        } else {
//
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
//        }

        clientID = getString(R.string.clientID);
        apiKey = getString(R.string.apiKey);
        lstResults = findViewById(R.id.lstResults);
        spinFilter = findViewById(R.id.spinFilter);
        btnSearch = findViewById(R.id.btnSearch);
        txtSearch = findViewById(R.id.txtSearch);
        btnMap = findViewById(R.id.btnMap);

//        latitude = lastKnownLocation.getLatitude();
//        longitude = lastKnownLocation.getLongitude();

        recomRestaurants(latitude, longitude, "explore?section=food&limit=5");

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String filter = setFilter();

                //Search for restaurants by the given search terms and filters within 10Km.
                String url = "search?" + filter +
                        "&radius=10000&query=" + txtSearch.getText().toString();
                searchRestaurants(latitude, longitude, url);

            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(intent);

            }
        });

    }

    //Set the correct category ID for the filter.
    private String setFilter() {
        //If no filter was selected, the category ID for "Food" will be set automatically
        //to only get restaurants
        String filterTerm = "categoryId=4d4b7105d754a06374d81259";

        switch (spinFilter.getSelectedItem().toString()){
            case "Coffee":
                filterTerm = "categoryId=4bf58dd8d48988d1e0931735";
                break;
            case "Chinese":
                filterTerm = "categoryId=4bf58dd8d48988d145941735";
                break;
            case "Japanese":
                filterTerm = "categoryId=4bf58dd8d48988d111941735";
                break;
            case "Dessert":
                filterTerm = "categoryId=4bf58dd8d48988d1d0941735";
                break;
            case "Fast Food":
                filterTerm = "categoryId=4bf58dd8d48988d16e941735";
                break;
        }

        return filterTerm;
    }

    //Populates a list of recommended restaurants given the devices latitude and
    //longitude. Max of 5 restaurants in recommendation list.
    public void recomRestaurants(double latitude, double longitude, String inputUrl){
        String url = BASE_URL +
                inputUrl + "&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        JsonObjectRequest restaurantsObject = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            String name;
            Double lat, lng;
            List<Restaurant> result = new ArrayList<>(); //The resulting list of restaurants.

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    //Parse the JSON response up to the array of restaurant info.
                    JSONObject response_object = response.getJSONObject("response");
                    JSONArray groups_array = response_object.getJSONArray("groups");
                    JSONObject places = groups_array.getJSONObject(0);
                    JSONArray restaurants = places.getJSONArray("items");

                    for(int i = 0; i < restaurants.length(); i++){
                        JSONObject restaurant = restaurants.getJSONObject(i).getJSONObject("venue");
                        JSONObject location = restaurant.getJSONObject("location");

                        name = restaurant.getString("name");
                        lat = location.getDouble("lat");
                        lng = location.getDouble("lng");
                        result.add(new Restaurant(name, new LatLng(lat, lng)));
                    }
                    updateListView(result);

                }catch(JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(restaurantsObject);
    }
    public void searchRestaurants(double latitude, double longitude, String inputUrl){
        String url = BASE_URL +
                inputUrl + "&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        JsonObjectRequest restaurantsObject = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            String name;
            Double lat, lng;
          ArrayList  results = new ArrayList<>(); //The resulting list of restaurants.

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    //Parse the JSON response up to the array of restaurant info.
                    JSONObject response_object = response.getJSONObject("response");
                    JSONArray venues_array = response_object.getJSONArray("venues");


                    for(int i = 0; i < venues_array.length(); i++){
                        JSONObject restaurant = venues_array.getJSONObject(i);
                        JSONObject location = restaurant.getJSONObject("location");

                        name = restaurant.getString("name");
                        lat = location.getDouble("lat");
                        lng = location.getDouble("lng");
                        results.add(new Restaurant(name, new LatLng(lat, lng)));
                    }
                    updateListView(results);

                }catch(JSONException e)
                {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(restaurantsObject);
    }

    //takes a list of restaurants and puts there names in our list view.
    private void updateListView(List<Restaurant> restaurants) {
        itemsList = new ArrayList<>();
        locations = new ArrayList<>();
        //fetch the names of the restaurants and puts them in our items list.
        for (Restaurant restaurant:
             restaurants) {
            if ((restaurant.get_name() != null) && (restaurant.get_latlng() != null))
            {
                itemsList.add(restaurant.get_name());
                locations.add(restaurant.get_latlng());
            }

        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, itemsList);
        lstResults.setAdapter(adapter);

        lstResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        adapter.notifyDataSetChanged();
    }
}

