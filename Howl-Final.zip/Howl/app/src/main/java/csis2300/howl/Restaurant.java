package csis2300.howl;

import com.google.android.gms.maps.model.LatLng;

public class Restaurant {

    //I've only added these three fields for now. More can be added later
    //depending on what we decide to add.
    private String _name;
    private Double _latitude;
    private Double _longitude;
    private String _id;
    private LatLng ll;

    public Restaurant(String _name, LatLng ll) {
        this._name = _name;
        this.ll = ll;

    }

    public String get_id() {
        return _id;
    }

    public void set_id(String id) {
        this._id = id;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public Double get_latitude() {
        return _latitude;
    }

    public void set_latitude(Double _latitude) {
        this._latitude = _latitude;
    }

    public Double get_longitude() {
        return _longitude;
    }

    public void set_latlng(LatLng ll) {
        this.ll = ll;
    }
    public LatLng get_latlng() {
        return ll;
    }

    public void set_longitude(Double _longitude) {
        this._longitude = _longitude;
    }
}
