package csis2300.howl;

import java.util.List;


//I started this class because I wanted to have the API calls done here rather than the MainActivity
//I realized I still don't know how to do that so I left this class here for now and will come back
//to it once I've researched how to do so.

//sample base url:
//https://api.foursquare.com/v2/venues/search?ll=40.7,-74&client_id=CLIENT_ID&client_secret=CLIENT_SECRET&v=YYYYMMDD

public class RestaurantParser {

    //Most, if not all, the API calls we will do will start with the BASE_URL.
    public static final String BASE_URL = "https://api.foursquare.com/v2/venues/";
    public  static final String API_VERSION = "&v=20181115";

    //Returns a list of recommended restaurants given the devices latitude and
    //longitude. Max of 5 restaurants in recommendation list.
    public static List<Restaurant> recomRestaurants(double latitude,
                                                    double longitude,
                                                    String clientID,
                                                    String apiKey){
        //https://api.foursquare.com/v2/venues/explore?ll=49.282156,-123.135317&section=food&limt=5&client_id=FQNQJTLBASX220XAL1H021VWE4WIQX0FU0UGSUH41UAU5YU0&client_secret=LDJ3MSUOXRI5AVERKJQZJMBIVW0LSIOUSUDGMYRUE0QXOYFS&v=20181115
        String url = BASE_URL +
                "explore?section=food&limt=5&ll=" +
                latitude + "," + longitude +
                "&client_id=" + clientID +
                "&client_secret=" + apiKey +
                API_VERSION;

        return null;
    }
}
