package csis2300.howl;

public class Restaurant {

    //I've only added these three fields for now. More can be added later
    //depending on what we decide to add.
    private String _name;
    private Double _latitude;
    private Double _longitude;
    private String _id;

    public Restaurant(String _name, Double _latitude, Double _longitude) {
        this._name = _name;
        this._latitude = _latitude;
        this._longitude = _longitude;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String id) {
        this._id = id;
    }

    public String get_name() {
        return _name;
    }

    public void set_name(String _name) {
        this._name = _name;
    }

    public Double get_latitude() {
        return _latitude;
    }

    public void set_latitude(Double _latitude) {
        this._latitude = _latitude;
    }

    public Double get_longitude() {
        return _longitude;
    }

    public void set_longitude(Double _longitude) {
        this._longitude = _longitude;
    }
}
